package com.familyexpense.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class ExpenseDb extends SQLiteOpenHelper {
    private static final String DB="family_expense.db";
    public ExpenseDb(Context c){super(c,DB,null,1);}
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, description TEXT, amount REAL, paidBy TEXT, category TEXT, participants TEXT, createdAt INTEGER, source TEXT)");
    }
    public void onUpgrade(SQLiteDatabase db,int oldV,int newV){}
    public long add(String d,double a,String p,String cat,String parts,String src){
        ContentValues v=new ContentValues(); v.put("description",d); v.put("amount",a); v.put("paidBy",p);
        v.put("category",cat); v.put("participants",parts); v.put("createdAt",System.currentTimeMillis()); v.put("source",src);
        return getWritableDatabase().insert("expenses",null,v);
    }
    public double total(){
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE createdAt>=?",new String[]{String.valueOf(startOfMonth())});
        double x=0; if(c.moveToFirst()) x=c.getDouble(0); c.close(); return x;
    }
    public String recent(){
        Cursor c=getReadableDatabase().rawQuery("SELECT description,amount,paidBy,category FROM expenses ORDER BY createdAt DESC LIMIT 12",null);
        StringBuilder s=new StringBuilder();
        while(c.moveToNext()) s.append(c.getString(0)).append("  ₹").append(String.format(Locale.US,"%.2f",c.getDouble(1)))
            .append(" • ").append(c.getString(3)).append(" • ").append(c.getString(2)).append("\n");
        c.close(); return s.length()==0?"No expenses yet.":s.toString();
    }
    private long startOfMonth(){
        Calendar c=Calendar.getInstance(); c.set(Calendar.DAY_OF_MONTH,1); c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0); return c.getTimeInMillis();
    }
}
