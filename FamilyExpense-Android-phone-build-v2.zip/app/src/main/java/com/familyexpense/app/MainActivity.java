package com.familyexpense.app;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.provider.Settings;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    ExpenseDb db; TextView total,recent,status; WifiSyncServer sync;
    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        db=new ExpenseDb(this); total=findViewById(R.id.total); recent=findViewById(R.id.recent); status=findViewById(R.id.status);
        findViewById(R.id.addExpense).setOnClickListener(v->addManual());
        findViewById(R.id.permissions).setOnClickListener(v->setupPermissions());
        findViewById(R.id.startWifi).setOnClickListener(v->{sync=new WifiSyncServer();sync.start(this);status.setText("Wi-Fi sync host started on port 48765. Keep this phone on the family Wi-Fi.");});
        refresh();
        checkPending();
    }
    void refresh(){total.setText("₹"+String.format(Locale.US,"%.2f",db.total())); recent.setText(db.recent());}
    void addManual(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(20,0,20,0);
        EditText d=new EditText(this); d.setHint("Description / merchant");
        EditText a=new EditText(this); a.setHint("Amount"); a.setInputType(2|8192);
        box.addView(d);box.addView(a);
        new android.app.AlertDialog.Builder(this).setTitle("Add expense").setView(box).setPositiveButton("Save",(x,w)->{
            try{double amount=Double.parseDouble(a.getText().toString()); String desc=d.getText().toString().trim(); if(desc.isEmpty())desc="Expense";
                db.add(desc,amount,"Shiva","Other","Shiva","manual"); refresh();
            }catch(Exception ignored){}
        }).setNegativeButton("Cancel",null).show();
    }
    void setupPermissions(){
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.READ_SMS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.READ_SMS,Manifest.permission.RECEIVE_SMS},40);
        try{startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));}catch(Exception ignored){}
    }
    void checkPending(){
        android.content.SharedPreferences p=getSharedPreferences("pending",0);
        if(p.contains("amount")){
            float amount=p.getFloat("amount",0); String merchant=p.getString("merchant","Unknown merchant");
            new android.app.AlertDialog.Builder(this).setTitle("Transaction detected")
                .setMessage("₹"+amount+" at "+merchant+"\n\nAdd this as an expense?")
                .setPositiveButton("Add",(d,w)->{db.add(merchant,amount,"Shiva","Other","Shiva","sms/notification");p.edit().clear().apply();refresh();})
                .setNegativeButton("Ignore",(d,w)->p.edit().clear().apply()).show();
        }
    }
    @Override protected void onResume(){super.onResume();checkPending();refresh();}
}
