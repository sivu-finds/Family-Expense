package com.familyexpense.app;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.app.Notification;
import android.os.Bundle;

public class TransactionNotificationListener extends NotificationListenerService {
    @Override public void onNotificationPosted(StatusBarNotification sbn){
        Notification n=sbn.getNotification();
        Bundle e=n.extras;
        CharSequence title=e.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text=e.getCharSequence(Notification.EXTRA_TEXT);
        String body=(title==null?"":title.toString())+" "+(text==null?"":text.toString());
        TransactionParser.Result r=TransactionParser.parse(body);
        if(r!=null && r.debit){
            getSharedPreferences("pending",0).edit()
                .putString("merchant",r.merchant).putFloat("amount",(float)r.amount).apply();
        }
    }
}
