package com.familyexpense.app;

import java.util.regex.*;

public class TransactionParser {
    public static class Result { public double amount; public String merchant; public boolean debit; public Result(double a,String m,boolean d){amount=a;merchant=m;debit=d;} }
    public static Result parse(String text){
        if(text==null) return null;
        String t=text.replaceAll("\\s+"," ").trim();
        Pattern p=Pattern.compile("(?i)(?:rs\\.?|inr|₹)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)");
        Matcher m=p.matcher(t); if(!m.find()) return null;
        double amount;
        try{ amount=Double.parseDouble(m.group(1).replace(",","")); }catch(Exception e){return null;}
        boolean debit=t.matches("(?i).*\\b(debit|debited|spent|paid|purchase|sent|withdrawn|transferred)\\b.*");
        if(!debit && t.matches("(?i).*\\b(credit|credited|received|refund)\\b.*")) return null;
        String merchant="Unknown merchant";
        Matcher at=Pattern.compile("(?i)(?:at|to|from|merchant)\\s+([A-Za-z0-9&._ -]{2,40})").matcher(t);
        if(at.find()) merchant=at.group(1).trim().replaceAll("[.!,;]+$","");
        else {
            Matcher pay=Pattern.compile("(?i)\\b(?:UPI|IMPS|POS)\\b.*?([A-Za-z][A-Za-z0-9&._ -]{2,30})").matcher(t);
            if(pay.find()) merchant=pay.group(1).trim();
        }
        return new Result(amount,merchant,debit);
    }
}
