package com.familyexpense.app;

import android.content.*;
import android.provider.Telephony;
import android.telephony.SmsMessage;

public class TransactionSmsReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent){
        if(!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        for(SmsMessage sms: Telephony.Sms.Intents.getMessagesFromIntent(intent)){
            String body=sms.getMessageBody();
            TransactionParser.Result r=TransactionParser.parse(body);
            if(r!=null && r.debit){
                // Store a pending transaction locally. The production UI should ask for confirmation.
                context.getSharedPreferences("pending",0).edit()
                    .putString("merchant",r.merchant).putFloat("amount",(float)r.amount).apply();
            }
        }
    }
}
