package com.familyexpense.app;

import java.io.*;
import java.net.*;
import android.content.Context;

public class WifiSyncServer {
    private ServerSocket server;
    public void start(Context context) {
        try {
            server=new ServerSocket(48765);
            new Thread(()->{
                while(!server.isClosed()){
                    try {
                        Socket s=server.accept();
                        // v1 scaffold: future implementation will exchange encrypted expense records.
                        s.close();
                    } catch(Exception ignored){}
                }
            }).start();
        } catch(Exception ignored){}
    }
    public void stop(){try{if(server!=null)server.close();}catch(Exception ignored){}}
}
